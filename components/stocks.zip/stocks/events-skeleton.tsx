const placeholderEvents = [
  {
    date: '2023-04-01',
    headline: 'Ontvang een lijst van evenementen',
    description: 'Een lijst genereren met alle evenementen in een tabelindeling'
  },
  {
    date: '2023-04-02',
    headline: 'Ontvang een lijst van evenementen',
    description: 'Een lijst genereren met alle evenementen in een tabelindeling'
  },
  // Add additional events here with dates between today and the end of 2024
]

export const EventsSkeleton = () => {
  return (
    <div className="-mt-2 flex w-full flex-col gap-2 py-4">
      {placeholderEvents.map(event => (
        <div
          key={event.date}
          className="flex shrink-0 flex-col gap-1 rounded-lg bg-zinc-800 p-4"
        >
          <div className="w-fit rounded-md bg-zinc-700 text-sm text-transparent">
            {event.date}
          </div>
          <div className="w-fit rounded-md bg-zinc-700 text-transparent">
            {event.headline}
          </div>
          <div className="w-auto rounded-md bg-zinc-700 text-transparent">
            {event.description.slice(0, 70)}...
          </div>
        </div>
      ))}
    </div>
  )
}
